{ 
    "cmd": ["python3", "-u", "$file"], 
}
