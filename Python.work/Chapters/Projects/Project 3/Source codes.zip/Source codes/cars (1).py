cars = ['bmw', 'audi', 'toyota', 'subaru',"Ford", "Mahindra","Suzuki","Porche"]  
print(cars)

cars.reverse()
print(cars)
