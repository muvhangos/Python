# Printing a greeting message
print("Hello, Python World!")