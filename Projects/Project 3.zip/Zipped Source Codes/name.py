name = "elon musk"
print(name.upper())
print(name.lower())
