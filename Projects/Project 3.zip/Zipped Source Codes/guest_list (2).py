guests = ["Nelson Mandela", " Michael Jackson","Bill clinton"," Ophray Winfrey"]
first_invite = f"Dear Sir {guests [0]., ["we Cordialy invite you to our g20 summit to be held in mandela square , "sandton"]
second_invite = f"Dear Sir {guests [1]., ["we are Cordialy invite you to our g20 summit to be held in mandela square , sandton"]
third_invite = f"Dear Sir {guests [2]., ["we are Cordialy invite you to our g20 summit to be held in mandela square , sandton"]
fourth_invite = f"Dear Sir {guests [3]., ["we are Cordialy invite you to our g20 summit to be held in mandela square , sandton"]
print(first_invite)
print(second_invite)
print(third_invite)
print(fourth_invite)
