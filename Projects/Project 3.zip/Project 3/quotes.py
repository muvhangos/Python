def greet_user(username):
 """Display a simple message."""
 print(f"Hello everyone, {username.title()}!")
greet_user('one of my favourite book is "This is the Day of your Miracle"!)
print (message)