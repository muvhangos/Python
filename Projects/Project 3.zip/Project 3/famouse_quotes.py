message = "It is always Impossible before it is done, by Nelson Mandela.!"
print(message)