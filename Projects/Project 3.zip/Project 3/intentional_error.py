friends = 1['john', 'eric', 'jerry' 'nana', 'elson', "kate", " Shaailesh"]
print (friends)