animal= ['dog', 'horse', 'cow']
for animal in animal:
 print(f"{animal.title()}, would made a good animal!")
 print(f"I love animals")