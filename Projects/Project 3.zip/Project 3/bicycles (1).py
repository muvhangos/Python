bicycles = ['trek','cannondale', "Bmx","redline']
message = f"My first bicycle was a {bicycles[0].title()}

print(message)