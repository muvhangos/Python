message = "come here now"
print (message)