guests = ['bill clinton', 'walter sisulu', 'nelson mandela', 'jimmy swagart']
print(guests)
too_busy= 'jimmy swagart'
guests.remove(too_busy)
print(guests)
print(f"\nA {too_busy.title()} is too busy.")