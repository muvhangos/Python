mesage = "!"
print(mesage)