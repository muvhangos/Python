names = ['peter', 'michael', 'John', 'kate']
print(names)