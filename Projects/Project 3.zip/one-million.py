for value in range(1, 11000000):
 print(value)