for value in range(1, 1000000):
 print(value)