document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('greet-btn');
  button.addEventListener('click', () => {
    alert('Hope you have a fantastic day!');
  });
});