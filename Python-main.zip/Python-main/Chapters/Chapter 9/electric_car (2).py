node_modules
.DS_Store